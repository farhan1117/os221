int main() {
    printf("Hello, my student ID is 1906306155\n");

    return 0;
}
